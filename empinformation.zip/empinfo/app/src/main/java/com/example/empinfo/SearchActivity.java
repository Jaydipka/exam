package com.example.empinfo;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SearchActivity extends AppCompatActivity {
    TextView search;
    Button btn;
    Db db = new Db(this, null, null,1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        search=findViewById(R.id.searchTxt);
        btn=findViewById(R.id.button);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor cursor = db.searchEmp(search.getText().toString());
                StringBuffer buffer = new StringBuffer();
                AlertDialog.Builder builder = new AlertDialog.Builder(SearchActivity.this);
                   while (cursor.moveToNext()) {
                    buffer.append("empId :" + cursor.getString(0) + "\n");
                    buffer.append("empName :" + cursor.getString(1) + "\n");
                    buffer.append("empDesingnation :" + cursor.getString(2) + "\n");
                    buffer.append("empPhone :" + cursor.getString(3) + "\n");
                    buffer.append("empEmail :" + cursor.getString(4) + "\n");
                    buffer.append("\n");
                }

                builder.setCancelable(true);
                builder.setTitle("Employee Records");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
    }
}